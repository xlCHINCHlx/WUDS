from subprocess import call

call (["apt-get", "-y", "install", "iw", "python-pcapy", "sqlite3", "screen", "git"])

#call(["./run"])

import subprocess

output=subprocess.check_output("./run.sh",shell=True)