iface=`grep IFACE config.py | cut -d'=' -f 2 | sed "s/['\" ]//g"`
iw dev wlp0s29u1u8 interface add $iface type monitor
ifconfig $iface up
python ./core.py
ifconfig $iface down
iw dev $iface del
