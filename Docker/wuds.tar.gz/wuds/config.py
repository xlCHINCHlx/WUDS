
#=========
# CONTROL
#=========

# (STR) WLAN interface in monitor mode
IFACE = 'wlp0s29u1u8mon'

# (LIST) List of MAC addresses expected within the premises
MAC_LIST = [
    '00:21:86:fb:e6:f1',
    '4a:1d:70:c2:28:b2',
    'C0:7C:D1:68:6D:B8',
    'C0:7C:D1:68:6D:C0',
    '88:C6:63:CE:A0:C6',
    '38:AA:3C:8D:07:E0',
    '00:23:69:61:d9:ae',
    '64:9a:be:21:1f:57',
    '0a:56:b3:a8:fa:a3',
    '3c:ab:8e:5e:d1:0a',
    'ac:5f:3e:d9:5a:93',
    'b8:c7:5d:4a:c9:5b',    
    'a6:e8:f2:06:2b:85',
    'f4:37:b7:00:a2:f4',
    '60:c5:47:0c:e3:2e',
    '8c:70:5a:81:75:14',
    '5c:0a:5b:e7:07:81',
    '90:18:7c:c1:8e:26',
    '70:14:a6:a5:36:6e',
    '6c:40:08:5c:dc:9f',
    '38:71:de:21:5e:37',
    'da:d7:b1:06:c4:44',
    'd8:50:e6:87:d7:64',
    '00:26:b6:f0:d8:b7',
    '56:1d:4a:36:f6:d2',
    'f0:4f:7c:07:a5:14',
    '02:af:7b:9c:2e:06',
    '3e:ec:df:74:31:7c', 
    'c0:bd:d1:fa:20:2b',
    '80:ed:2c:d8:b9:b4',
    '7c:0b:c6:93:f2:d5',
] 

# (STR) Vendor name to report for probes from Local Admin MAC addresses
ADMIN_OUI = 'Admin OUI'

# (BOOL) Automatically white list Local Admin MAC addresses
# WARNING...
# iOS MAC randomization uses Local Admin MAC addresses. Ignoring Local
# Admin MAC addresses will cause false negatives. However, NOT ignoring
# Local Admin MAC addresses will cause false positives.
ADMIN_IGNORE = False

# (INT) RSSI threshold for triggering alerts
RSSI_THRESHOLD = -50

# (INT) Number of seconds between alerts for persistent foreign probes
ALERT_THRESHOLD = 30

# (STR) Path to the database file
LOG_FILE = 'log.db'

# (INT) Determines which probes are stored in the database
# 0 = all probes
# 1 = all foreign probes
# 2 = all probes on the premises
# 3 = all foreign probes on the premises
# 4 = only probes that generate alerts
LOG_LEVEL = 3

# (BOOL) Enable/Disable stdout debugging messages
DEBUG = True

#========
# ALERTS
#========

# (BOOL) Enable/Disable alert modules
ALERT_SMS = True
ALERT_PUSHOVER = False

#==================
# ALERT_SMS CONFIG
#==================

# (STR) SMTP server hostname and port (TLS required) for sending alerts
SMTP_SERVER = 'smtp.gmail.com:587'

# (STR) Mail server credentials for sending alerts
SMTP_USERNAME = 'n65ghz@gmail.com'
SMTP_PASSWORD = 'F6u1C7kK'

# (STR) SMS email address (through cellular service provider) for receiving alerts
SMS_EMAIL = 'n6unltd@gmail.com'

#=======================
# ALERT_PUSHOVER CONFIG
#=======================

# (STR) API and User keys from pushover.net
PUSHOVER_API_KEY = ''
PUSHOVER_USER_KEY = ''
